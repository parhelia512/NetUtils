IP Connections was written to gather statistics of IP connections to InterBase (or to any other TCP) server. IP Connections writes information (IP Address, Host Name (if resolve is successful), Date and Time of connect and disconnect) into the log file and shows information about active connections on the screen.

IPScan is a console (multi-thread) application allows very quickly get information about computers in network which uses protocol TCP/IP.

MIB II Monitor allows you to get SNMP information from any SNMP device supporting MIB II in your network in convenient form. SNMP Service required.

NetView allows very quickly get information about network resources in the Microsoft Network and save this information to the file.

Remote Wake Up allows properly equipped PCs to be "awakened" from a powered-off state from any computer across the network. The NIC and an OS must support Wake On LAN technology.

SnmpEye contains SNMP Management software for Windows. SNMP Service required.

SessionSpy enables you view and manage open files and users connected to file shares on the computer.

WNetStat provides basic information about IPv4 and IPv6 protocol on your host, including the following: 

  NIC Table; 
  ARP Table; 
  IP Address Table; 
  Route Table; 
  Connections Table; 
  Interface Statistics (total statistics or separate on each interface); 
  IP Statistics; 
  ICMP Statistics; 
  TCP Statistics; 
  UDP Statistics. 

The usage of this software is easy and understandable and, I believe, doesn't require additional explanation.

Contact me through e-mail address: vcrits@mail.ru
